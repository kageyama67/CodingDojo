﻿using Bowling_High;
using Microsoft.VisualStudio.TestTools.UnitTesting;
namespace UnitTest
{
    [TestClass]
    public class UnitTest
    {
        private Bowling game;
        [TestInitialize]
        public void Setup()
        {
            game = new Bowling();
        }
        [TestMethod]
        public void Test_01_GutterGame()
        {
            ContinueRoll(0, 20);
            Assert.AreEqual(0, game.Score());
        }
        [TestMethod]
        public void Test_02_AllOne()
        {
            ContinueRoll(1, 20);
            Assert.AreEqual(20, game.Score());
        }
        [TestMethod]
        public void Test_03_OneSpair()
        {
            game.Roll(5);
            game.Roll(5);
            game.Roll(3);
            ContinueRoll(0, 17);
            Assert.AreEqual(16, game.Score());
        }
        [TestMethod]
        public void Test_04_OneStrike()
        {
            game.Roll(10);
            game.Roll(4);
            game.Roll(3);
            ContinueRoll(0, 16);
            Assert.AreEqual(24, game.Score());
        }
        [TestMethod]
        public void Test_05_PerfectGame()
        {
            ContinueRoll(10, 12);
            Assert.AreEqual(300, game.Score());
        }
        [TestMethod]
        public void Test_06_LastFlameSpair()
        {
            ContinueRoll(0, 18);
            game.Roll(5);
            game.Roll(5);
            game.Roll(3);
            Assert.AreEqual(13, game.Score());
        }
        [TestMethod]
        public void Test_07_LastFlameTurkey()
        {
            ContinueRoll(0, 18);
            game.Roll(10);
            game.Roll(10);
            game.Roll(10);
            Assert.AreEqual(30, game.Score());
        }

        private void ContinueRoll(int pins, int count)
        {
            for (int i = 0; i < count; i++)
            {
                game.Roll(pins);
            }
        }
    }
}