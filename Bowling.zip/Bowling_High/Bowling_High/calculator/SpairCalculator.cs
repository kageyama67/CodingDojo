﻿using Bowling_High.data;
using static Bowling_High.Const;
namespace Bowling_High.calculator
{
    public class SpairCalculator : BaseCalculator
    {
        public SpairCalculator(Score score) : base(score)
        {
        }
        public override int BonusPoint(int flameCount, RollCount rollCount)
        {
            return score.Specify(CurrentCount(rollCount), OffSet2, Range1);
        }
        public override int RollCount(int flameCount, RollCount rollCount)
        {
            return Count1;
        }
    }
}
