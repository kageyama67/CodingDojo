﻿using Bowling_High.data;
using static Bowling_High.Const;
namespace Bowling_High.calculator
{
    public class BaseCalculator
    {
        protected readonly Score score;
        public BaseCalculator(Score score)
        {
            this.score = score;
        }
        public virtual int BonusPoint(int flameCount, RollCount rollCount)
        {
            return Bonus0;
        }
        public virtual int RollCount(int flameCount, RollCount rollCount)
        {
            if (flameCount == LastFlame)
                return Count0;
            return Count2;
        }
        protected int CurrentCount(RollCount rollCount)
        {
            return rollCount.CurrentCount();
        }
    }
}
