﻿using Bowling_High.data;
using static Bowling_High.Const;
namespace Bowling_High.calculator
{
    public class StrikeCalculator : BaseCalculator
    {
        public StrikeCalculator(Score score) : base(score)
        {
        }
        public override int BonusPoint(int flameCount, RollCount rollCount)
        {
            return score.Specify(CurrentCount(rollCount), OffSet1, Range2);
        }
        public override int RollCount(int flameCount, RollCount rollCount)
        {
            return Count1;
        }
    }
}
