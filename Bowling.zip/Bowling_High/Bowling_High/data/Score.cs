﻿using System.Collections.Generic;
using System.Linq;
using static Bowling_High.Const;
namespace Bowling_High.data
{
    public class Score
    {
        private readonly List<int> score = new List<int>();
        public void Add(int num)
        {
            score.Add(num);
        }
        public int Sum()
        {
            return score.Sum();
        }
        public int Specify(int count, int offset, int range)
        {
            return score.Skip(count + offset).Take(range).Sum();
        }
        public bool IsSpair(RollCount rollCount)
        {
            return Specify(rollCount.CurrentCount(), OffSet0, Range2) == MaxPont;
        }
        public bool IsStrike(RollCount rollCount)
        {
            return Specify(rollCount.CurrentCount(), OffSet0, Range1) == MaxPont;
        }
    }
}
