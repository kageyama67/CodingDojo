﻿namespace Bowling_High.data
{
    public class RollCount
    {
        private int rollCount = 0;
        public void Add(int num)
        {
            rollCount += num;
        }
        public int CurrentCount()
        {
            return rollCount;
        }
    }
}
