﻿using Bowling_High.calculator;
using Bowling_High.data;
using static Bowling_High.Const;
namespace Bowling_High
{
    public class Bowling
    {
        // 上級/超級
        //(3) すべてのプリミティブ型と文字列型はクラスでラップする(パラメータに意味を持たせる) for文のカウンタは除外。。
        //(4) 1行につきドットは1つまで(デメテルの法則、再利用性の向上)
        //(7) 1クラスのメンバ変数は2つまで(基本は1つに努める)
        //(8) ファーストクラスコレクションを使用する(コレクション変数を持つクラスのメンバはそれのみにする)
        //(2) else句を使わない(Strategyパターン、ポリモーフィズム)
        //(9) getter/setterプロパティの利用禁止(求めるな命じよ、データを持つクラスに仕事をさせる)
        private readonly Score score = new Score();
        public void Roll(int pins)
        {
            score.Add(pins);
        }
        public int Score()
        {
            RollCount rollCount = new RollCount();
            for (int flameCount = 0; flameCount <= LastFlame; flameCount++)
            {
                BaseCalculator calculator = GetCalculator(flameCount, rollCount);
                score.Add(BonusPoint(calculator, flameCount, rollCount));
                rollCount.Add(RollCount(calculator, flameCount, rollCount));
            }
            return score.Sum();
        }
        private BaseCalculator GetCalculator(int flameCount, RollCount rollCount)
        {
            if (flameCount == LastFlame)
                return new BaseCalculator(score);
            if (score.IsStrike(rollCount))
                return new StrikeCalculator(score);
            if (score.IsSpair(rollCount))
                return new SpairCalculator(score);
            return new BaseCalculator(score);
        }
        private int RollCount(BaseCalculator calculator, int flameCount, RollCount rollCount)
        {
            return calculator.RollCount(flameCount, rollCount);
        }
        private int BonusPoint(BaseCalculator calculator, int flameCount, RollCount rollCount)
        {
            return calculator.BonusPoint(flameCount, rollCount);
        }
    }
}