﻿namespace Bowling_Middle
{
    public class Const
    {
        public const int MaxPont = 10;
        public const int LastFlame = 9;
        public const int OffSet0 = 0;
        public const int OffSet1 = 1;
        public const int OffSet2 = 2;
        public const int Range1 = 1;
        public const int Range2 = 2;
        public const int Bonus0 = 0;
        public const int Count0 = 0;
        public const int Count1 = 1;
        public const int Count2 = 2;
    }
}