﻿using System.Collections.Generic;
using System.Linq;
using static Bowling_Middle.Const;
namespace Bowling_Middle
{
    public class Bowling
    {
        // 中級
        //(1)1つのメソッドでインデントは１階層まで(単一責務、抽象化レベル)
        //(5)名前を省略しない。命名は2つの単語まで(命名は難しいときはクラス分割のサイン)
        //(6)クラスは50行以内(すべてのエンティティを小さく保つ) コメントなしで。。
        private readonly List<int> score = new List<int>();
        public void Roll(int pins)
        {
            score.Add(pins);
        }
        public int Score()
        {
            var rollCount = 0;
            for (int flameCount = 0; flameCount <= LastFlame; flameCount++)
            {
                score.Add(BonusPoint(flameCount, rollCount));
                rollCount += RollCount(flameCount, rollCount);
            }
            return score.Sum();
        }
        private int BonusPoint(int flameCount, int rollCount)
        {
            if (flameCount == LastFlame)
                return Bonus0;
            if (IsStrike(rollCount))
                return score.Skip(rollCount + OffSet1).Take(Range2).Sum();
            if (IsSpair(rollCount))
                return score.Skip(rollCount + OffSet2).Take(Range1).Sum();
            return Bonus0;
        }
        private int RollCount(int flameCount, int rollCount)
        {
            if (flameCount == LastFlame)
                return Count0;
            if (IsStrike(rollCount))
                return Count1;
            return Count2;
        }
        private bool IsSpair(int rollCount)
        {
            return score.Skip(rollCount).Take(2).Sum() == MaxPont;
        }
        private bool IsStrike(int rollCount)
        {
            return score.Skip(rollCount).Take(1).Sum() == MaxPont;
        }
    }
}