﻿using System.Collections.Generic;
using System.Linq;
namespace Bowling_Low
{
    public class Bowling
    {
        // 初級
        //マジックナンバー禁止
        //重複コード禁止
        private const int MaxPont = 10;
        private readonly List<int> score = new List<int>();
        public void Roll(int pins)
        {
            score.Add(pins);
        }
        public int Score()
        {
            const int LastFlame = 9;
            const int OffSet1 = 1;
            const int OffSet2 = 2;
            const int Range1 = 1;
            const int Range2 = 2;
            const int Bonus0 = 0;
            const int Count1 = 1;
            const int Count2 = 2;
            var rollCount = 0;
            for (int flameCount = 0; flameCount <= LastFlame; flameCount++)
            {
                if (flameCount == LastFlame)
                {
                    score.Add(Bonus0);
                    continue;
                }
                if (IsStrike(rollCount))
                {
                    score.Add(score.Skip(rollCount + OffSet1).Take(Range2).Sum());
                    rollCount += Count1;
                    continue;
                }
                if (IsSpair(rollCount))
                {
                    score.Add(score.Skip(rollCount + OffSet2).Take(Range1).Sum());
                }
                rollCount += Count2;
            }
            return score.Sum();
        }
        private bool IsSpair(int rollCount)
        {
            return score.Skip(rollCount).Take(2).Sum() == MaxPont;
        }
        private bool IsStrike(int rollCount)
        {
            return score.Skip(rollCount).Take(1).Sum() == MaxPont;
        }
    }
}
